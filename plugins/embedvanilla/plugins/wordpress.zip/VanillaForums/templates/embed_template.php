<?php
/**
 * Template Name: Vanilla Forum Template
 *
 * A custom page template for a Vanilla Forum.
 *
 * The "Template Name:" bit above allows this to be selectable
 * from a dropdown menu on the edit page screen.
 *
 */

get_header();
the_content();
get_footer();